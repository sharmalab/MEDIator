/*
 * REST client to access TCIA directly.
 *
 */

package edu.emory.bmi.datarepl.tcia_rest_api;