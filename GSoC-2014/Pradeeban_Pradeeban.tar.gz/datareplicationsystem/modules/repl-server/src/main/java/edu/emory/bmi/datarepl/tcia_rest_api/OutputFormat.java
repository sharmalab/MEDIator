package edu.emory.bmi.datarepl.tcia_rest_api;

public enum OutputFormat {
    xml,csv,json
}