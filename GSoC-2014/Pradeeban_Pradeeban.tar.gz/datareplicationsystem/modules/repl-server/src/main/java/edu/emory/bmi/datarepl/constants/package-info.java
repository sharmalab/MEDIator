/*
 * Constants of the Data Replication Server
 *
 */

package edu.emory.bmi.datarepl.constants;
