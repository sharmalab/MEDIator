/*
 * Interfacing Layer, including the implementation for Mashape TCIA integration.
 *
 */

package edu.emory.bmi.datarepl.interfacing;